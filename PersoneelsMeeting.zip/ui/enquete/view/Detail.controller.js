sap.ui.controller("PersoneelsMeeting.enquete.view.Detail", {

	onInit: function() {

		var oTableModel = new sap.ui.model.odata.ODataModel("/PersoneelsMeeting/services/enquete.xsodata", true);
		this.getView().setModel(oTableModel, "Table");

		var oUser = new sap.ui.model.json.JSONModel("/services/userapi/currentUser");
		this.getView().setModel(oUser, "User");
		
		var oRecordModel = {
			"ENQUETE_ID": "3",
			"BNAME": "JEI03834",
			"ANSWER": ""
		};
		this.oRecordModel = new sap.ui.model.json.JSONModel(oRecordModel);
		this.getView().setModel(this.oRecordModel, "Record");
	},

	onRadiobuttonSelect: function(oEvent) {
		var oTable = this.getView().getModel("Table");
		var oEntry = this.getView().getModel("Record").getData();
		var iIndex = oEvent.getParameter("selectedIndex");
		oEntry.ANSWER = JSON.stringify(iIndex);

		oTable.setHeaders({
			"content-type": "application/json;charset=utf-8"
		});

		oTable.create('/EnqueteItm', oEntry, null, jQuery.proxy(function() {

			alert("Create successful");

		}, this), jQuery.proxy(function() {

			alert("Create failed");

		}, this));
	}
});